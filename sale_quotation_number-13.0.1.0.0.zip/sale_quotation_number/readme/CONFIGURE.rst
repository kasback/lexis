To configure this module you need to go to Sales -> Configuration and uncheck 'Use same enumeration for quotations and sale orders'.
